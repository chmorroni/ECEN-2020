#include <stdint.h>

void itoa(uint32_t num, char * string);
void ulltoa(uint64_t num, char * string);
